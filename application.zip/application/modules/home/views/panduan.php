<section class="jumbotron bg-white">
  <div class="container">
    <h2><?= $panduan->head_panduan; ?></h2>
    <?= $panduan->panduan; ?>
  </div>
</section>