   <footer class="footer mt-auto py-3 bg-light">
     <div class="container">
       <span class="text-muted">Footer</span>
     </div>
   </footer>

   <script src="<?= base_url('assets/home/'); ?>js/bootstrap.bundle.min.js"></script>


   </body>

   </html>