

<?php

if ($content) {
  $this->load->view($content);
} else {
  echo "halaman tidak ditemukan";
}
