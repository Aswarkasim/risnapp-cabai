<section class="jumbotron bg-white">
  <div class="container">
    <h2>Kontak</h2>
    <?= $konfigurasi->nama_aplikasi; ?>
  </div>
</section>